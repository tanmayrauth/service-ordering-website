<?php 
 $to ="+918108252865@vtext.com";
 $from="tanmayrauth@gmail.com";
 $message=" hello this is sucessful";
 $headers="From: $from \n";
 mail($to,'',$message,$headers);
 
 ?>