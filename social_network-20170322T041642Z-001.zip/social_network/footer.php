  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">

<footer >

            <div class="col-sm-12 asd" style="background-color:#262626;padding-top:30px;">
                <div class="col-sm-3" style="left:5%;">
                  <p style="font-size:1.5em;color:white;">

                  Over <b>1,00,000</b> unique Registrations last month</p>
                    <p style="color:white;font-size:1.1em;">India's fastest connecting platform</p>
                </div>
                <div class="col-sm-2" style="position:relative;left:5%;">

                    <p style="font-size:1.5em;color:white;padding-top:10px;"> Address: <br>3rd floor, 3227,</p>
                    <p style="color:white;font-size:1.1em;">Sunshine Towers,</p>
                    <p style="color:white;font-size:1.1em;">Chembur,Mumbai-76,</p>

                </div>
                <div class="col-sm-2 footli">
                    <ul>
                        <li><a href="#">Site Map</a></li>
                        <hr>
                        <li><a href="#">Featured Ads</a></li>
                        <hr>
                        <li><a href="#">Locations Map</a></li>
                        <hr>
                        <li><a href="#">Popular Searches</a></li>
                        <hr>

                    </ul>
                </div>
                 <div class="col-sm-2 footli">
                    <ul>
                        <li><a href="main/tac.html">Terms of Use </a></li>
                        <hr>
                        <li><a href="main/conus.html"> Contact Us</a></li>
                        <hr>
                        <li><a href="main/help1.html">Help</a></li>
                        <hr>
                        <li><a href="main/abus.html">About Us</a></li>
                        <hr>
                    </ul>
                </div>
                 <div class="col-sm-2 social-tabs">
                     <p style="color:white;font-size:1.2em;text-align:center;">JOIN US TODAY</p>
                     <a class="btn btn-social-icon btn-google">
                        <span class="fa fa-google"></span>
                    </a>
                     <a class="btn btn-social-icon btn-reddit">
                        <span class="fa fa-reddit"></span>
                    </a>
                     <a class="btn btn-social-icon btn-facebook">
                        <span class="fa fa-facebook"></span>
                    </a>
                     <a class="btn btn-social-icon btn-instagram">
                        <span class="fa fa-instagram"></span>
                    </a>
                     <br>
                     <a class="btn btn-social-icon btn-twitter">
                        <span class="fa fa-twitter"></span>
                    </a>
                     <a class="btn btn-social-icon btn-pinterest">
                        <span class="fa fa-pinterest"></span>
                    </a>
                    <a class="btn btn-social-icon btn-tumblr">
                        <span class="fa fa-tumblr"></span>
                    </a>
                </div>
            </div>
        </footer>
